import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  port = "3306",
  database = "pydb",
  user="root",
  password=""
)

print(mydb)